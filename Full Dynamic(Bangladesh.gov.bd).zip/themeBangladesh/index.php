<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   <?php wp_head();?>
</head>
<body>
    <!-- header part start -->
    <div class="cont">
        <div class="row header">
            <div class="col-lg-6">
                <p>বাংলাদেশ জাতীয় তথ্য বাতায়ন</p>
            </div>
            <div class="col-lg-6 header_right d-flex justify content-end">
                <p>২৪ মাঘ, ১৪২৯</p>
                <a href="#">English</a>
            </div>
        </div>
    </div>
    <!-- header part end -->
    <!-- logo part start -->
    <div class="cont">
        <div class="row">
            <div class="col-lg-5 logo_left">
                <?php the_custom_logo();?>
            </div>
            <div class="col-lg-5 logo_search">
                <input type="text"Placeholder="খুঁজুন "><button>অনুসন্ধান</button>
            </div>
            <div class="col-lg-2 logo_right d-flex justify content-end">
                <div class="logo_1">
                    <img src="<?php echo get_template_directory_uri()?>./assets/images/header/a2i-logo-footer.png" alt="">
                </div>
                <div class="logo_2">
                    <p>সাথে থাকুন:</p>
                    <img src="<?php echo get_template_directory_uri()?>./assets/images/header/facebook-icon.png" alt="">
                    <img src="<?php echo get_template_directory_uri()?>./assets/images/header/twitter-blue-icon.png" alt="">
                    <img src="<?php echo get_template_directory_uri()?>./assets/images/header/youtube-icon.png" alt="">
                    <img src="<?php echo get_template_directory_uri()?>./assets/images/header/gplus-icon.png" alt="">
                    
                </div>
            </div>
        </div>
    </div>
    <!-- logo part end -->
    <!-- menu part start -->
    <div class="cont">
        <div class="row navbar-expand menu">
          <?php 
          wp_nav_menu([
            'theme_location'=>'TM',
            'menu_class'=>'navbar-nav'
          ]);
          ?>
            
        </div>
    </div>
    <!-- menu part end -->
    <!-- hero part start -->
    <div class="cont">
        <div class="row">
            <div class="col-lg-8">
                <div class="banner mt-2">
                    <img src="<?php echo get_template_directory_uri()?>./assets/images/padmabanner.jpg"class="d-block w-100" alt="">
                </div>
                <div class="slider mt-2">
                    <div id="carouselExampleFade" class="carousel slide carousel-fade">
                      <?php
                      $cat = new WP_Query([
                        'post_type'=>'post',
                        'category_name'=>'slider1'
                      ]);
                      ?>
                        <div class="carousel-inner">
                          <?php
                          $x = 0;
                          while($cat->have_posts()){$cat->the_post();
                            $x++;
                          ?>
                          <div class="carousel-item <?=($x==1)?'active':''?>">
                            <?php the_post_thumbnail();?>
                          </div>
                          <?php }?>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
                          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                          <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
                          <span class="carousel-control-next-icon" aria-hidden="true"></span>
                          <span class="visually-hidden">Next</span>
                        </button>
                      </div>
                </div>
                <div class="tab">
                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                          <button class="nav-link " id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">জনপ্রিয় সেবা</button>
                        </li>
                        <li class="nav-item" role="presentation">
                          <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">নতুন সেবা</button>
                        </li>
                        <li class="nav-item" role="presentation">
                          <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">মোবাইল সেবা</button>
                        </li>
                        <li class="nav-item" role="presentation">
                          <button class="nav-link" id="pills-contac-tab" data-bs-toggle="pill" data-bs-target="#pills-contac" type="button" role="tab" aria-controls="pills-contac" aria-selected="false">দপ্তর ভিত্তিক সেবা</button>
                        </li>
                        <li class="nav-item" role="presentation">
                          <button class="nav-link" id="pills-conta-tab" data-bs-toggle="pill" data-bs-target="#pills-conta" type="button" role="tab" aria-controls="pills-conta" aria-selected="false">সকল ই-সেবা</button> 
                        </li>
                      </ul>
                      <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
                            <div class="row">
                                <div class="col-lg-2">
                                <div class="tab_1">
                                    <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/1/1.png" alt=""></a>
                                    <p>অর্থ ও বাণিজ্য</p>
                                </div>
                            </div>
                                <div class="col-lg-2">
                                <div class="tab_1">
                                    <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/1/2.png" alt=""></a>
                                    <p>অনলাইন আবেদন </p>
                                </div>
                            </div>
                                <div class="col-lg-2">
                                <div class="tab_1">
                                    <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/1/3.png" alt=""></a>
                                    <p>শিক্ষা-বিষয়ক</p>
                                </div>
                            </div>
                                <div class="col-lg-2">
                                <div class="tab_1">
                                    <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/1/4.png" alt=""></a>
                                    <p>অনলাইন নিবন্ধন</p>
                                </div>
                            </div>
                                <div class="col-lg-2">
                                <div class="tab_1">
                                    <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/1/5.png" alt=""></a>
                                    <p>কৃষি</p>
                                </div>
                            </div>
                                <div class="col-lg-2">
                                <div class="tab_1">
                                    <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/1/6.png" alt=""></a>
                                    <p>নিয়োগ সংক্রান্ত</p>
                                </div>
                            </div>
                                <div class="col-lg-2">
                                <div class="tab_1">
                                    <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/1/7.png" alt=""></a>
                                    <p>পাসপোর্ট, ভিসা ও ইমিগ্রেশন</p>
                                </div>
                            </div>
                                <div class="col-lg-2">
                                <div class="tab_1">
                                    <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/1/8.png" alt=""></a>
                                    <p>ইউটিলিটি বিল</p>
                                </div>
                            </div>
                                <div class="col-lg-2">
                                <div class="tab_1">
                                    <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/1/9.png" alt=""></a>
                                    <p>ভর্তির আবেদন</p>
                                </div>
                            </div>
                                <div class="col-lg-2">
                                <div class="tab_1">
                                    <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/1/10.png" alt=""></a>
                                    <p>পরীক্ষার ফলাফল</p>
                                </div>
                            </div>
                               
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
                          <div class="row">
                            <div class="col-lg-2">
                            <div class="tab_1">
                                <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/2/1.png" alt=""></a>
                                <p>মৎস্য ও প্রাণী</p>
                            </div>
                        </div>
                            <div class="col-lg-2">
                            <div class="tab_1">
                                <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/2/2.png" alt=""></a>
                                <p>ভর্তির আবেদন</p>
                            </div>
                        </div>
                            <div class="col-lg-2">
                            <div class="tab_1">
                                <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/2/3.png" alt=""></a>
                                <p>ট্রেজারি চালান</p>
                            </div>
                        </div>
                            <div class="col-lg-2">
                            <div class="tab_1">
                                <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/2/4.png" alt=""></a>
                                <p>টিকিট বুকিং ও ক্রয়</p>
                            </div>
                        </div>
                            <div class="col-lg-2">
                            <div class="tab_1">
                                <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/2/5.png" alt=""></a>
                                <p>নিয়োগ সংক্রান্ত</p>
                            </div>
                        </div>
                            <div class="col-lg-2">
                            <div class="tab_1">
                                <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/2/6.png" alt=""></a>
                                <p>পাসপোর্ট, ভিসা ও ইমিগ্রেশন</p>
                            </div>
                        </div>
                            <div class="col-lg-2">
                            <div class="tab_1">
                                <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/2/1.png" alt=""></a>
                                <p>কৃষি</p>
                            </div>
                        </div>
                            <div class="col-lg-2">
                            <div class="tab_1">
                                <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/2/8.png" alt=""></a>
                                <p>ইউটিলিটি বিল</p>
                            </div>
                        </div>
                            <div class="col-lg-2">
                            <div class="tab_1">
                                <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/1/9.png" alt=""></a>
                                <p>ভর্তির আবেদন</p>
                            </div>
                        </div>
                            <div class="col-lg-2">
                            <div class="tab_1">
                                <a href="#"><img src="<?php echo get_template_directory_uri()?>./assets/images/tab/1/10.png" alt=""></a>
                                <p>পরীক্ষার ফলাফল</p>
                            </div>
                        </div>
                           
                        </div>
                        </div>
                        <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">
                          <?php
                          $tab = new WP_Query([
                            'post_type'=>'post',
                            'category_name'=>'tab'
                          ]);
                          ?>
                          <div class="row">
                            <?php
                            while($tab->have_posts()){$tab->the_post();
                            ?>
                            <div class="col-lg-2">
                            <div class="tab_1">
                                <a href="#"><?php the_post_thumbnail();?></a>
                                <?php the_title();?>
                            </div>
                        </div>
                        <?php }?>
                            
                           
                        </div>
                        </div>
                        <div class="tab-pane fade" id="pills-contac" role="tabpanel" aria-labelledby="pills-contac-tab" tabindex="0"></div>
                        <div class="tab-pane fade" id="pills-conta" role="tabpanel" aria-labelledby="pills-conta-tab" tabindex="0"></div>
                      </div>
                </div>
                <div class="news">
                 <p><?php dynamic_sidebar('news');?></p>
                </div>
                <div class="b">
                  <button>সকল</button>
                </div>
                <div class="row">
                  <p><?php dynamic_sidebar('photo');?></p>
                </div>
                <div class="row video mt-2">
                  <p><?php dynamic_sidebar('video');?></p>
                </div>
            </div>
            <div class="col-lg-4 side_bar">
              <p><?php dynamic_sidebar('sidebar');?></p>
            </div>
        </div>
    </div>
    <!-- hero part end -->
    <!-- footer part start -->
    <div class="cont mt-5">
      <div class="row">
        <img src="<?php echo get_template_directory_uri()?>./assets/images/footer/download.png" alt="">
      </div>
      <div class="row mt-4">
        <div class="col-lg-8">
        
        <div class="row navbar-expand menu1">
          <?php 
          wp_nav_menu([
            'theme_location'=>'FM',
            'menu_class'=>'navbar-nav'
          ]);
          ?>
            
        
    </div>
        </div>
        <div class="col-lg-4 ft">
          <p>পরিকল্পনা ও বাস্তবায়নে: এটুআই, মন্ত্রিপরিষদ বিভাগ, বিসিসি, বেসিস, ডিওআইসিটি</p>
        </div>
      </div>
      <div class="row fb mt-4">
        <div class="col-lg-8">
          <p>সাইটটি শেষ হাল-নাগাদ করা হয়েছে: ২০২৩-০২-০৫ ০৬:১৯:৫২</p>
        </div>
        <div class="col-lg-4 fb_1 text-end">
          <p>কারিগরি সহায়তায়:</p>
          <img src="<?php echo get_template_directory_uri()?>./assets/images/footer/np-logo-set.png" alt="">
        </div>
      </div>
    </div>
    <!-- footer part end -->
    <?php wp_footer();?>
</body>
</html>